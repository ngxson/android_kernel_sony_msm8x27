#!/sbin/busybox sh
set +x
_PATH="$PATH"
export PATH=/sbin

busybox cd /
busybox date >>boot.txt
exec >>boot.txt 2>&1
busybox rm /init

# include device specific vars
source /sbin/bootrec-device

# create directories
busybox mkdir -m 755 -p /dev/block
busybox mkdir -m 755 -p /dev/input
busybox mkdir -m 555 -p /proc
busybox mkdir -m 755 -p /sys
busybox mkdir -m 755 -p /system

# create device nodes
busybox mknod -m 600 /dev/block/mmcblk0 b 179 0
busybox mknod -m 600 /dev/block/mmcblk0p25 b 179 25
busybox mknod -m 600 ${BOOTREC_EVENT_NODE}
busybox mknod -m 666 /dev/null c 1 3

# mount filesystems
busybox mount -t proc proc /proc
busybox mount -t sysfs sysfs /sys
busybox mount -t ext4 /dev/block/mmcblk0p25 /system

#blue
if [[ ! -f /system/kernel/dont_guide ]]; then
	busybox echo 1 > /sys/nui/logo
fi
if [[ ! -f /system/kernel/no_boot_vib ]]; then
	busybox echo 100 > /sys/class/timed_output/vibrator/enable
fi
#busybox echo 80 > /sys/class/leds/wled/brightness
busybox echo ${BOOTREC_RED_LED_ON} > ${BOOTREC_CONTROL_LED}
busybox echo ${BOOTREC_GREEN_LED_OFF} > ${BOOTREC_CONTROL_LED}
busybox echo ${BOOTREC_BLUE_LED_ON} > ${BOOTREC_CONTROL_LED}
busybox cat ${BOOTREC_EVENT} > /dev/keycheck&
busybox sleep 3
# We want to boot up faster
busybox echo 0 > /sys/nui/nooc
busybox echo 1 > /sys/devices/system/cpu/cpu1/online
busybox echo 1782000 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
busybox echo 1782000 > /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq
# boot decision
if [ -s /dev/keycheck ] || busybox grep -q warmboot=0x77665502 /proc/cmdline ; then
	if [[ ! -f /system/kernel/no_boot_vib ]]; then
		busybox echo 400 > /sys/class/timed_output/vibrator/enable
	fi
	if [[ ! -f /system/kernel/dont_guide ]]; then
		busybox echo 2 > /sys/nui/logo
	fi
	busybox echo 0 > /sys/module/msm_fb/parameters/align_buffer
	busybox echo 'RECOVERY BOOT' >>boot.txt
	# cyan led for recoveryboot
	busybox echo ${BOOTREC_RED_LED_OFF} > ${BOOTREC_CONTROL_LED}
	busybox echo ${BOOTREC_GREEN_LED_ON} > ${BOOTREC_CONTROL_LED}
	busybox echo ${BOOTREC_BLUE_LED_ON} > ${BOOTREC_CONTROL_LED}
	# recovery ramdisk
	busybox mknod -m 600 ${BOOTREC_FOTA_NODE}
	busybox mount -o remount,rw /
	busybox ln -sf /sbin/busybox /sbin/sh
	if [[ ! -f /system/kernel/no_fota ]]; then
		extract_elf_ramdisk -i ${BOOTREC_FOTA} -o /sbin/ramdisk-recovery.cpio -t / -c
	fi
	busybox rm /sbin/sh
	busybox cpio -i < /sbin/ramdisk-recovery.cpio
else
	if [[ ! -f /system/kernel/no_boot_vib ]]; then
		busybox echo 80 > /sys/class/timed_output/vibrator/enable
	fi
	if [[ ! -f /system/kernel/dont_guide ]]; then
		busybox echo 3 > /sys/nui/logo
	fi
	busybox echo 'ANDROID BOOT' >>boot.txt
	busybox cpio -i < /system/kernel/patch00.cpio
	busybox cpio -i < /system/kernel/patch1.cpio
	if [ -f "/system/kernel/patch.cpio" ]; then
		busybox echo 'patch.cpio found.' >>boot.txt
		busybox cpio -i < /system/kernel/patch.cpio
		# poweroff LED
		busybox echo ${BOOTREC_RED_LED_OFF} > ${BOOTREC_CONTROL_LED}
		busybox echo ${BOOTREC_GREEN_LED_OFF} > ${BOOTREC_CONTROL_LED}
		busybox echo ${BOOTREC_BLUE_LED_OFF} > ${BOOTREC_CONTROL_LED}
		(busybox sleep 12; busybox echo 80 > /sys/class/leds/wled/brightness)&
		#tweak for nui kernel
		if [[ -f /system/kernel/auto_vdd ]]; then
			VDD_DIR=/sys/devices/system/cpu/cpufreq/vdd_table/vdd_levels
			busybox echo "384000 750000" > ${VDD_DIR}
			busybox echo "432000 800000" > ${VDD_DIR}
			busybox echo "486000 800000" > ${VDD_DIR}
			busybox echo "540000 825000" > ${VDD_DIR}
			busybox echo "594000 825000" > ${VDD_DIR}
			busybox echo "648000 850000" > ${VDD_DIR}
			busybox echo "702000 875000" > ${VDD_DIR}
			busybox echo "756000 925000" > ${VDD_DIR}
			busybox echo "810000 925000" > ${VDD_DIR}
			busybox echo "864000 950000" > ${VDD_DIR}
			busybox echo "918000 950000" > ${VDD_DIR}
			busybox echo "972000 975000" > ${VDD_DIR}
			busybox echo "1026000 975000" > ${VDD_DIR}
			busybox echo "1080000 1025000" > ${VDD_DIR}
			busybox echo "1134000 1025000" > ${VDD_DIR}
			busybox echo "1188000 1050000" > ${VDD_DIR}
			busybox echo "1242000 1050000" > ${VDD_DIR}
			busybox echo "1296000 1075000" > ${VDD_DIR}
			busybox echo "1350000 1075000" > ${VDD_DIR}
			busybox echo "1404000 1087500" > ${VDD_DIR}
			busybox echo "1458000 1090000" > ${VDD_DIR}
			busybox echo "1512000 1150000" > ${VDD_DIR}
			busybox echo "1620000 1200000" > ${VDD_DIR}
			busybox echo "1728000 1200000" > ${VDD_DIR}
		fi
		if [[ -f /system/kernel/overclock ]]; then
			busybox echo 1026000 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
			busybox echo 1026000 > /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq
			busybox echo $(busybox cat /system/kernel/overclock) > /sys/nui/nooc
		else
			busybox echo 1026000 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
			busybox echo 1026000 > /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq
			busybox echo 1 > /sys/nui/nooc
		fi
		if [[ -f /system/kernel/nuibrightness ]]; then
			busybox echo $(busybox cat /system/kernel/nuibrightness) > /sys/nui/nuibrightness
		fi
		if [[ -f /system/kernel/kcal_rgb ]]; then
			busybox echo $(busybox cat /system/kernel/kcal_rgb) > /sys/devices/platform/mdp.525057/kcal
		fi
		if [[ -f /system/kernel/dt2w ]]; then
			busybox echo $(busybox cat /system/kernel/dt2w) > /sys/android_touch/doubletap2wake
		fi
		if [[ -f /system/kernel/s2w ]]; then
			busybox echo $(busybox cat /system/kernel/s2w) > /sys/android_touch/swipe2wake
		fi
		if [[ -f /system/kernel/torch ]]; then
			busybox echo $(busybox cat /system/kernel/torch) > /sys/nui/torch
		fi
		if [[ -f /system/kernel/focus_key ]]; then
			busybox echo $(busybox cat /system/kernel/focus_key) > /sys/nui/focus_key
		fi
		if [[ -f /system/kernel/camera_key ]]; then
			busybox echo $(busybox cat /system/kernel/camera_key) > /sys/nui/camera_key
		fi
		if [[ -f /system/kernel/key_scroff ]]; then
			busybox echo 1 > /sys/nui/key_scroff
		fi
		if [[ -f /system/kernel/focus_key_scroff ]]; then
			busybox echo $(busybox cat /system/kernel/focus_key_scroff) > /sys/nui/focus_key_scroff
		fi
		if [[ -f /system/kernel/camera_key_scroff ]]; then
			busybox echo $(busybox cat /system/kernel/camera_key_scroff) > /sys/nui/camera_key_scroff
		fi
		if [[ -f /system/kernel/proximity ]]; then
			busybox echo 1 > /sys/nui/proximitysens
		fi
		if [[ -f /system/kernel/dyn_fsync ]]; then
			busybox echo 1 > /sys/kernel/dyn_fsync/Dyn_fsync_active
		fi
		if [[ -f /system/kernel/dt2w_vib ]]; then
			busybox echo 1 > /sys/android_touch/doubletap2wake_vib
		else
			busybox echo 0 > /sys/android_touch/doubletap2wake_vib
		fi
		if [[ -f /system/kernel/zeroprecent ]]; then
			busybox echo 1 > /sys/nui/zeroprecent
		else
			busybox echo 0 > /sys/nui/zeroprecent
		fi
		if [[ -f /system/kernel/initd ]]; then
			busybox echo "" >> /init.rc
			busybox echo "service sysinit /system/bin/logwrapper /system/xbin/busybox run-parts /system/etc/init.d" >> /init.rc
			busybox echo "   user root" >> /init.rc
			busybox echo "   disabled" >> /init.rc
			busybox echo "   oneshot" >> /init.rc
			busybox echo "" >> /init.rc
		fi
		if [[ -f /system/kernel/vib_level ]]; then
			busybox echo $(busybox cat /system/kernel/vib_level) > /sys/class/timed_output/vibrator/level
			busybox echo "Applied vibrator level"
		fi
		if [[ -f /system/kernel/level_short ]]; then
			busybox echo 1 > /sys/nui/level_short
			if [[ -f /system/kernel/vib_level_short ]]; then
				busybox echo $(busybox cat /system/kernel/vib_level_short) > /sys/class/timed_output/vibrator/level_short
			fi
		else
			busybox echo 0 > /sys/nui/level_short
		fi
		# pre-config
		busybox echo 320000000 > /sys/devices/platform/kgsl-3d0.0/kgsl/kgsl-3d0/max_gpuclk
		busybox echo 320000000 > /sys/class/kgsl/kgsl-3d0/max_gpuclk
		busybox echo "sioplus" > /sys/block/mmcblk1/queue/scheduler
		busybox echo "sioplus" > /sys/block/mmcblk0/queue/scheduler
	else
		if [[ ! -f /system/kernel/dont_guide ]]; then
			busybox echo 2 > /sys/nui/logo
		fi
		# If no ramdisk found, boot to TWRP
		busybox echo 400 > /sys/class/timed_output/vibrator/enable
		busybox echo 0 > /sys/module/msm_fb/parameters/align_buffer
		busybox echo 'RECOVERY BOOT' >>boot.txt
		# cyan led for recoveryboot
		busybox echo ${BOOTREC_RED_LED_OFF} > ${BOOTREC_CONTROL_LED}
		busybox echo ${BOOTREC_GREEN_LED_ON} > ${BOOTREC_CONTROL_LED}
		busybox echo ${BOOTREC_BLUE_LED_ON} > ${BOOTREC_CONTROL_LED}
		# recovery ramdisk
		busybox mknod -m 600 ${BOOTREC_FOTA_NODE}
		busybox mount -o remount,rw /
		busybox ln -sf /sbin/busybox /sbin/sh
		if [[ ! -f /system/kernel/no_fota ]]; then
			extract_elf_ramdisk -i ${BOOTREC_FOTA} -o /sbin/ramdisk-recovery.cpio -t / -c
		fi
		busybox rm /sbin/sh
		busybox cpio -i < /sbin/ramdisk-recovery.cpio
	fi
fi

# kill the keycheck process
busybox pkill -f "busybox cat ${BOOTREC_EVENT}"

busybox umount /proc
busybox umount /sys
busybox umount /system

busybox rm -fr /dev/*
busybox date >>boot.txt
export PATH="${_PATH}"
exec /init
